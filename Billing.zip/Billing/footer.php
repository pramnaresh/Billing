<style>.footer {
    background-color: #222; /* Dark background */
    color: #fff; /* White text */
    text-align: center;
    padding: 5px 0;
    position: fixed; /* Sticks to bottom */
    width: 100%;
    bottom: 0;
    font-size: 14px;
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.2);
}

.footer p {
    margin: 0;
    font-weight: 500;
    letter-spacing: 0.5px;
}
</style>
<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?>  UNIADROITECH INNOVATION PRIVATE LIMITED All Rights Reserved</p>
</footer>
