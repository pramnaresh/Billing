<?php 
include 'sidebar.php';
include 'header.php';
session_start();
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <script src="script.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>

<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #212529;
    }
    h1, h4 {
        text-align: center;
        margin-bottom: 10px;
    }
    .container {
        max-width: 990px;
        margin: auto;
        padding: 20px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 30px;
    }
    .bg-section {
        background: #e9f5e9;
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 10px;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    .btn {
        width: 100%;
    }
    .scrollable-section {
        max-height: 250px; /* Adjust height as needed */
        overflow-y: auto;
    }
    .bg-section {
       max-height: 300px;
       overflow-y: auto;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 12px;
        text-align: center;
        border: 1px solid #ddd;
    }
    th {
        background-color: #f8f9fa;
    }
    .btn-primary {
        background-color: #007bff;
        border: none;
    }
    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>

<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="bg-section">
                <h4>Product List</h4>
                <form method="post" action="cart_action.php?action=add_multiple">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Price (₹)</th>
                                <th>Quantity</th>
                                <th>Select</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $select_query = "SELECT * FROM products";
                            $result = mysqli_query($conn, $select_query);

                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '
                                    <tr>
                                        <td>
                                            <img src="images/' . $row['image'] . '" width="50" height="50" alt="' . $row['name'] . '">
                                        </td>
                                        <td><strong>' . $row['name'] . '</strong></td>
                                        <td style="color:blue;">₹' . number_format($row['price'], 2) . '</td>
                                        <td>
                                            <input type="number" name="quantities[' . $row['id'] . ']" value="1" min="1" class="form-control product-quantity">
                                        </td>
                                        <td>
                                             <input type="checkbox" name="product_codes[]" value="' . $row['id'] . '" style="width: 20px; height: 20px;">
                                        </td>

                                    </tr>';
                                }
                            } else {
                                echo '<tr><td colspan="5" class="text-center text-danger">No products available</td></tr>';
                            }
                            ?>                        
                        </tbody>
                    </table>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Add Selected to Cart</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  
    <hr>
    <h2 class="text-center">Shopping Cart</h2>
    <?php include 'cart_ui.php'; ?>
</div>
</body>
</html>
<?php include 'footer.php'; ?>
