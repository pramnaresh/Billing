<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Database connection
$servername = "localhost";
$username = "root";  
$password = "";      
$dbname = "billingsystem";  

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Debugging: Output the variables
    echo "Email: $email <br>";
    echo "Password: $password <br>";

    // Check in the `admin` table first
    $query = "SELECT * FROM admin WHERE email='$email'";
    $result = $conn->query($query);

    // Debugging: Check the query result
    echo "Result: " . $result->num_rows . "<br>";

    if ($result->num_rows == 1) {
        // Admin found
        $admin = $result->fetch_assoc();
        
        if (password_verify($password, $admin['password'])) {
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['role'] = 'admin';  // Manually assign role as 'admin'
            
            header("Location: admin_dashboard.php"); // Redirect to admin dashboard
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        // Check in the `users` table if not found in `admin`
        $query = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($query);

        if ($result->num_rows == 1) {
            // Regular user found
            $user = $result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = 'user';  // Assign role as 'user'
                
                header("Location: user_dashboard.php"); // Redirect to user dashboard
                exit();
            } else {
                echo "Invalid password!";
            }
        } else {
            echo "User not found!";
        }
    }
}

$conn->close();
?>
