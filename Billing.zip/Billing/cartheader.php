  <!-- header --> 
  <header class="header"> 
    <div class="header_body"> 
        <!-- <a href="add_item.php" class="logo">TechnoBling</a>  -->
      <nav class="navbar"> 
        <a href="add_item.php">Add Products</a> 
        <a href="cartview_products.php">View Products</a> 
        <a href="">Shopit</a> 
       </nav> 

       <!-- Shopping cart icon -->
        <a href="" class="cart"><i class="fa-solid fa-cart-shopping"></i><span><sup>4</sup></span></a>
        <!-- <div id="menu-btn" class="fas fa-bars"></div> -->
    </div>
</header>