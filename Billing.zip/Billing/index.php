<?php
include 'sidebar.php';
include 'header.php';
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Software</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <script src="script.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.13/jspdf.plugin.autotable.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(214, 226, 169);
            color: #212529;
        }
        h1, h4 {
            text-align: center;
            margin-bottom: 10px;
        }
        .container {
            width: 1000px;
            height: 550px;
            margin: auto;
            padding: 20px;
            background: rgb(174, 223, 243);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .bg-section {
            background: rgb(177, 223, 164);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
        }
        .btn {
            width: 100%;
        }
        .scrollable-section {
            max-height: 250px; /* Adjust height as needed */
            overflow-y: auto;
        }
        .bg-section {
           max-height: 300px; /* Adjust based on your layout */
           overflow-y: auto;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <input type="hidden" id="totalAmountHidden" name="totalAmountHidden">

    <h3 class="text-center">Billing System</h3>

    <div class="row">
        <div class="col-md-12">
            <div class="bg-section">
                <h4>Products</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Price (₹)</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $select_query = "SELECT * FROM products";
                        $result = mysqli_query($conn, $select_query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr style="background-color:rgb(249, 249, 249); border-bottom: 1px solid #ddd;">
                                    <td style="padding: 10px; text-align: center;">
                                        <img src="images/' . $row['image'] . '" width="50" height="50" alt="' . $row['name'] . '">
                                    </td>
                                    <td style="padding: 10px; font-weight: bold; color: #333;">' . $row['name'] . '</td>
                                    <td style="padding: 10px; color:rgb(70, 9, 237);">₹' . $row['price'] . '</td>
                                    <td style="padding: 10px;">
                                        <input type="number" class="form-control product-quantity" 
                                            data-price="' . $row['price'] . '" value="0" 
                                            style="width: 60px; text-align: center; border-radius: 5px; border: 1px solid #ccc; padding: 5px;">
                                    </td>
                                </tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4" class="text-center" style="padding: 15px; font-weight: bold; color: red;">No products available</td></tr>';
                        }
                    ?>                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <div class="row mt-3">
            <div class="col-md-4">
               <button class="btn btn-warning" onclick="calculateTotal()">Calculate Total</button>
           </div>
          <div class="col-md-4">
              <button class="btn btn-danger" onclick="clearBill()">Clear Bill</button>
          </div>
          <div class="col-md-4">
              <button class="btn btn-success" onclick="generateBill()">Generate Bill</button>
         </div>
    </div></br>
    <div class="col-md-6 d-flex justify-content-end">
       <h4 id="totalAmount" class="fw-bold text-danger p-2 rounded" style="background-color: #f8d7da; border: 1px solid #f5c6cb;">
        Total: ₹0
      </h4>
     </div>

</div>

<script>
function calculateTotal() {
    let total = 0;
    document.querySelectorAll('.product-quantity').forEach(input => {
        const price = parseFloat(input.getAttribute('data-price'));
        const quantity = parseInt(input.value) || 0;
        total += price * quantity;
    });
    document.getElementById('totalAmount').innerText = "Total: ₹" + total;
}
</script>

</body>
</html>
<?php include('footer.php');?>