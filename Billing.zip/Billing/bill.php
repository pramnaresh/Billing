<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customerName = $_POST['customerName'];
    $phoneNo = $_POST['phoneNo'];
    $billNo = $_POST['billNo'];
    $billDetails = $_POST['billDetails'];

    $file = fopen("bills/$billNo.txt", "w");
    fwrite($file, "Customer Name: $customerName\nPhone No: $phoneNo\nBill No: $billNo\n\nBill Details:\n$billDetails");
    fclose($file);

    echo "Bill saved successfully!";
}
?>
