<?php
session_start();
if (!isset($_SESSION['user_id'])) {  // Check if user is logged in (change from 'admin_id' to 'user_id')
    header("Location: login.php");  // Redirect to user login page
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "billingsystem";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT COUNT(*) AS user_count FROM users";
$result = $conn->query($query);
$user_data = $result->fetch_assoc();
$user_count = $user_data['user_count'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
     <?php include 'header.php'; ?>  <!-- Include the header here -->
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>User Panel</h2>
            <ul>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'user_dashboard.php') ? 'active' : '' ?>">
                    <a href="user_dashboard.php">Home</a>
                </li>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'registration.html') ? 'active' : '' ?>">
                    <a href="registration.html">Registration Page</a>
                </li>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'cart_view.php') ? 'active' : '' ?>">
                   <a href="cart_view.php">Add to cart</a>
                </li>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : '' ?>">
                   <a href="index.php">Billing System</a>
                </li>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'add_item.php') ? 'active' : '' ?>">
                   <a href="add_item.php">Add Item</a>
                </li>
                <li class="<?= (basename($_SERVER['PHP_SELF']) == 'products.php') ? 'active' : '' ?>">
                  <a href="products.php">Products</a>
               </li>
               <!-- <li class="<?= (basename($_SERVER['PHP_SELF']) == 'reports.php') ? 'active' : '' ?>">
                  <a href="reports.php">Reports</a>
              </li> -->
              <li class="<?= (basename($_SERVER['PHP_SELF']) == 'contact.php') ? 'active' : '' ?>">
                  <a href="contact.php">Contacts</a>
              </li>
              <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </aside>

        <main class="dashboard-content">
            <header>
                <?php
                if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
                    if ($_SESSION['role'] === 'user') {
                        echo "<h2>Hello, " . htmlspecialchars($_SESSION['username']) . "!</h2>";
                    } else {
                        echo "<h2>Hello, Guest!</h2>";  // In case the session does not exist
                    }
                } else {
                    echo "<h2>Welcome, Guest!</h2>";
                }
                ?>
                <p>Welcome to your user dashboard.</p>
            </header>

            <section class="cards">
                <div class="card">
                    <h3><?php echo $user_count; ?></h3>
                    <p>Total Registered Users</p>
                </div>
            </section>
        </main>
    </div>
</body>
</html>
<?php include 'footer.php'; ?>