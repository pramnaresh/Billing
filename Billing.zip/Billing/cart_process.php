<?php

echo "<pre>";
print_r($_POST);
print_r($_FILES);
echo "</pre>";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields exist
    if (!isset($_POST['productName']) || !isset($_POST['productPrice'])) {
        die(" Error: Missing form data!");
    }

    $productName = $_POST['productName'];
    $productPrice = $_POST['productPrice'];

    // Check if file is uploaded correctly
    if (!isset($_FILES['productImage']) || $_FILES['productImage']['error'] !== UPLOAD_ERR_OK) {
        die("Error: No file uploaded! Possible reasons:
        - Form is missing enctype='multipart/form-data'
        - File input name is incorrect (should be 'productImage')
        - PHP file uploads are disabled in php.ini
        - File is too large (check php.ini limits)
        - File upload encountered an error");
    }

    //  Create upload directory if it doesn't exist
    $targetDir = "uploads/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Validate file type
    $fileName = basename($_FILES["productImage"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

    $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');
    if (!in_array(strtolower($fileType), $allowedTypes)) {
        die("Error: Only JPG, JPEG, PNG, & GIF files are allowed.");
    }

    // Move uploaded file to 'uploads/' directory
    if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFilePath)) {
        echo "File uploaded successfully: $fileName";
    } else {
        die("Error: File upload failed.");
    }
}
?>
