<?php include('sidebar.php');?>
<?php include('header.php');?>
<?php include 'db_connect.php';
if(isset($_POST['add_product'])){
    $product_name=$_POST['product_name'];
    $product_price=$_POST['product_price'];
    $product_image=$_FILES['product_image']['name'];
    $product_image_temp_name=$_FILES['product_image']['tmp_name'];
    $product_image_folder='images/'.$product_image;
    
     $insert_query=mysqli_query($conn,"insert into products(name,price,image) values('$product_name','$product_price','$product_image')") or die("Insert query failed");
    if($insert_query){
        move_uploaded_file($product_image_temp_name,$product_image_folder);
        $display_message = "Product inserted successfully";
    }else{
        $display_message = "There is some error inserting product";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>addtocart</title>
    <!-- <link rel="stylesheet" href="css/cartview.css"> -->
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" defer></script>
    <script src="script.js" defer></script>
</head>
<style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #ef8181;
    margin: 0;
    padding: 0;
    height: 100%;
    overflow-x: hidden; 
    overflow-y: auto; 
}
.dashboard-content {
    margin-left: 250px; 
    padding: 20px;
}
.container {
    width: 600px;
    background-color: #fff;
    padding: 20px;
    margin-top: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}
h3.heading {
    font-size: 24px;
    font-weight: 600;
    color: #333;
    margin-bottom: 30px;
    text-align: center;
}
.diplay_message {
    background-color: #28a745;
    color: white;
    padding: 10px;
    border-radius: 5px;
    text-align: center;
    position: relative;
    margin-bottom: 20px;
}

.diplay_message i {
    position: absolute;
    right: 10px;
    top: 10px;
    cursor: pointer;
}
.add_product {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.input_fields {
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    width: 100%;
    box-sizing: border-box;
}

.input_fields:focus {
    border-color: #007bff;
    outline: none;
}
.submit_btn {
    background-color: #007bff;
    color: white;
    padding: 12px;
    border: none;
    border-radius: 8px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.submit_btn:hover {
    background-color: #0056b3;
}
.input_fields[type="file"] {
    padding: 8px;
}
.form-group {
    margin-bottom: 20px;
}
.card {
    border: 1px solid #ddd;
    border-radius: 10px;
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
}

.card:hover {
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.card img {
    max-height: 150px;
    object-fit: cover;
    border-radius: 8px;
}

.card h5 {
    font-size: 18px;
    font-weight: 600;
}
.btn-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.btn-primary:hover {
    background-color: #0056b3;
}
table {
    background-color: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
}

table th {
    background-color: #007bff;
    color: #fff;
    text-align: center;
}

table td, table th {
    padding: 12px;
    text-align: center;
    vertical-align: middle;
}
.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.btn-danger:hover {
    background-color: #bd2130;
}

.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
}

.btn-warning:hover {
    background-color: #e0a800;
}
.text-center {
    font-size: 18px;
    font-weight: 500;
    color: #555;
}

</style>
<body>
<main class="dashboard-content">
  <!-- form section -->
  <div class="container">
     <!-- message display -->

     <?php
     if(isset($display_message)){
      echo "<div class='diplay_message'>
      <span>$display_message</span>
      <i class='fas fa-times' onclick='this.parentElement.style.display='none'';></i>

      </div>";
     }
     ?>
        <section>
            <h3 class="heading">Add Products</h3>
            <form action="" class="add_product" method="post" enctype="multipart/form-data">
    
    <input type="texts" name="product_name"placeholder="Enter product name"class="input_fields" required>
    <input type="number" name="product_price"min="0" placeholder="Enter product price" class="input_fields" required>
    <input type="file" name="product_image" class="input_fields"accept="image/png, image/jpg, image/jpeg" required>
    <input type="submit" name="add_product" class="submit_btn" value="Add Product">
   
</form>
</section>
           
        </main>
    
</body>
</html>
<?php include('footer.php');?>
