document.getElementById('registrationForm').addEventListener('submit', function(event) {
    let password = document.getElementById('password').value;
    let confirmPassword = document.getElementById('confirm_password').value;
    let errorMessage = document.getElementById('error_message');
    
    if (password !== confirmPassword) {
        event.preventDefault();
        errorMessage.textContent = "Passwords do not match!";
    }
});

function calculateTotal() {
    let total = 0;
    document.querySelectorAll('.product-quantity').forEach(input => {
        const price = parseFloat(input.getAttribute('data-price'));
        const quantity = parseInt(input.value) || 0;
        total += price * quantity;
    });
    document.getElementById('totalAmount').innerText = "Total: ₹" + total;
}

function clearBill() {
    document.querySelectorAll('.product-quantity').forEach(input => {
        input.value = 0;  
    });
    document.getElementById('totalAmount').innerText = "Total: ₹0";  
}
function generateBill() {
    
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFont("helvetica", "bold");
    doc.text("Billing Invoice", 80, 15);

    let tableData = [];
    let totalAmount = 0;

    document.querySelectorAll(".product-quantity").forEach((input, index) => {
        const quantity = parseInt(input.value) || 0;
        if (quantity > 0) {
            const price = parseFloat(input.getAttribute("data-price"));
            const name = input.closest("tr").querySelector("td:nth-child(2)").innerText;
            const total = price * quantity;

            tableData.push([index + 1, name, "₹" + price, quantity, "₹" + total]);
            totalAmount += total;
        }
    });

    if (tableData.length === 0) {
        alert("Please add products before generating a bill.");
        return;
    }


    if (typeof doc.autoTable !== "function") {
        alert("AutoTable plugin is not loaded. Please check your script imports.");
        return;
    }

    doc.autoTable({
        head: [["S.No", "Product Name", "Price (₹)", "Quantity", "Total (₹)"]],
        body: tableData,
        startY: 30, 
        theme: "striped", 
        styles: { fontSize: 10 },
        headStyles: { fillColor: [44, 62, 80], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [240, 240, 240] },
    });

    let finalY = doc.lastAutoTable.finalY || 40; 

    doc.text(`Grand Total: ₹${totalAmount}`, 140, finalY + 10);

    doc.save("Bill_Invoice.pdf");
}

