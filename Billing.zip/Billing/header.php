<?php
// session_start();
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";
$role = isset($_SESSION['role']) ? $_SESSION['role'] : "user";
?>

<header class="header">
    <h2>Billing Management System</h2>
    <div class="user-options">
        <a href="login.html" class="btn user-btn">User Login</a>
        <a href="admin_login.php" class="btn admin-btn" target="_blank">Admin Login</a>
        <img src="images/user_logo.png" alt="User Logo" class="user-logo">
    </div>
</header>
