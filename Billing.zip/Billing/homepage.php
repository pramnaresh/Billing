<?php include('dashboard.php');?>
<?php

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if the user is not logged in
    header("Location: login.html");
    exit();
}

$username = $_SESSION['username']; // You can use the session variable to display the username
?>

<!-- <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2> -->
<!-- Rest of your page content here -->
