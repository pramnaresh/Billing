<aside class="sidebar">
    <h2>Dashboard</h2>
    <ul>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : '' ?>">
            <a href="dashboard.php">Home</a>
        </li>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'registration.html') ? 'active' : '' ?>">
            <a href="registration.html">Registration</a>
        </li>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'cart_view.php') ? 'active' : '' ?>">
            <a href="cart_view.php">Add to Cart</a>
        </li>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : '' ?>">
            <a href="index.php">Billing System</a>
        </li>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'add_item.php') ? 'active' : '' ?>">
            <a href="add_item.php">Add Item</a>
        </li>
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'product.php') ? 'active' : '' ?>">
            <a href="product.php">Products</a>
        </li>
        <!-- <li class="<?= (basename($_SERVER['PHP_SELF']) == 'reports.php') ? 'active' : '' ?>">
            <a href="reports.php">Reports</a>
        </li> -->
        <li class="<?= (basename($_SERVER['PHP_SELF']) == 'contact.php') ? 'active' : '' ?>">
            <a href="contact.php">Contact Us</a>
        </li>
        <li>
            <a href="logout.php">Logout</a>
        </li>
    </ul>
</aside>
