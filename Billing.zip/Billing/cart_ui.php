<div class="container">
    <?php if (!empty($_SESSION["cart_item"])) { ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th>
                <!-- <th>Code</th> -->
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Price</th>
                <th>Remove</th>
            </tr>
        </thead>
        <style>
            /* Cart UI Styles */
.container {
    width: 100%;
    margin-top: 40px;
    background-color: #fff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Product List Card Styles */
.card {
    border-radius: 8px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    background-color: #fff;
}

.card img {
    max-height: 50px;
    object-fit: cover;
    margin-bottom: 15px;
}

.card h5 {
    font-size: 1.1em;
    margin-bottom: 10px;
    color: #333;
}

.card p {
    font-size: 1.1em;
    color: #007bff;
}

/* Quantity and Add to Cart Button */
input[type="number"] {
    width: 100%;
    padding: 5px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

input[type="checkbox"] {
    margin-right: 10px;
}

/* Add to Cart Button */
button {
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 12px 25px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.text-center {
    text-align: center;
}
h2 {
    font-size: 2em;
    color: #333;
    margin-top: 30px;
    margin-bottom: 20px;
}

        </style>
        <tbody>
            <?php
            $total_quantity = 0;
            $total_price = 0;
            foreach ($_SESSION["cart_item"] as $item) {
                $item_price = $item["quantity"] * $item["price"];
            ?>
            <tr>
                <td><?php echo $item["name"]; ?></td>
                <!-- <td><?php echo $item["code"]; ?></td> -->
                <td><?php echo $item["quantity"]; ?></td>
                <td>₹<?php echo number_format($item["price"], 2); ?></td>
                <td>₹<?php echo number_format($item_price, 2); ?></td>
                <td><a href="cart_action.php?action=remove&id=<?php echo array_search($item, $_SESSION["cart_item"]); ?>" class="btn btn-danger">Remove</a></td>
            </tr>
            <?php
                $total_quantity += $item["quantity"];
                $total_price += $item_price;
            } ?>
            <tr>
                <td colspan="2"><strong>Total</strong></td>
                <td><strong><?php echo $total_quantity; ?></strong></td>
                <td colspan="2"><strong>₹<?php echo number_format($total_price, 2); ?></strong></td>
                <td></td>
            </tr>
        </tbody>
    </table>
    <a href="cart_action.php?action=empty" class="btn btn-warning">Empty Cart</a>
    <?php } else { ?>
    <p class="text-center">Your cart is empty.</p>
    <?php } ?>
</div><?php if (!empty($_SESSION["cart_item"])) { ?>
    <form method="post" action="generate_bill.php">
        <button type="submit" class="btn btn-success">Generate Bill</button>
    </form>
<?php } else { ?>
    <p class="text-center">Your cart is empty.</p>
<?php } ?>


