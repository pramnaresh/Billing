<?php include('sidebar.php');?>
<?php include('header.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<style>
.container {
    margin-top: 30px;
    height: 500px;
    width: 900px;
}
.card {
    padding: 20px;
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    background-color: #fff;
}
.card h4 {
    font-size: 1.5em;
    font-weight: bold;
    color: #333;
}

.card p.text-muted {
    font-size: 1em;
    color: #666;
}
.d-flex {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}
.contact-item {
    width: 40%;
    padding: 15px;
    background-color: #f7f7f7;
    border-radius: 10px;
    margin: 10px;
    transition: transform 0.3s, box-shadow 0.3s;
}
.contact-item:hover {
    transform: translateY(-10px);
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
}
.contact-item i {
    font-size: 2em;
    margin-bottom: 10px;
    transition: color 0.3s;
}

.contact-item:hover i {
    color: #007bff;
}
.contact-item p.fw-bold {
    font-size: 1.1em;
    margin-bottom: 5px;
}

.contact-item p.text-muted {
    font-size: 0.9em;
}
@media (max-width: 768px) {
    .contact-item {
        width: 45%;
    }
}
@media (max-width: 480px) {
    .contact-item {
        width: 100%;
    }
}
</style>
<body>
<div class="container ">
    <div class="card p-3 shadow-lg">
        <h4 class="text-center fw-bold">📞 Need Help? Contact Us!</h4>
        <p class="text-center text-muted">Our support team is available 24/7.</p>
        
        <div class="d-flex justify-content-around flex-wrap">
            <div class="contact-item text-center p-2">
                <i class="fas fa-phone-alt text-primary fs-4"></i>
                <p class="fw-bold m-1">+91 98765 43210</p>
                <p class="text-muted m-0">Customer Support</p>
            </div>

            <div class="contact-item text-center p-2">
                <i class="fas fa-headset text-success fs-4"></i>
                <p class="fw-bold m-1">+91 87654 32109</p>
                <p class="text-muted m-0">Technical Assistance</p>
            </div>

            <div class="contact-item text-center p-2">
                <i class="fas fa-envelope text-danger fs-4"></i>
                <p class="fw-bold m-1">adroitsoftwaretechnology@gmail.com</p>
                <p class="text-muted m-0">Email Us</p>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php include('footer.php');?>
<!-- Font Awesome for Icons -->
<script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
