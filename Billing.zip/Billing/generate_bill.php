<?php
session_start();
require('fpdf.php'); // Ensure you have the FPDF library installed

if (empty($_SESSION["cart_item"])) {
    echo "No items in the cart!";
    exit;
}

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Invoice', 0, 1, 'C');
        $this->Ln(5);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 10, 'Thank you for shopping with us!', 0, 0, 'C');
    }
}

// Create PDF instance
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Table Header
$pdf->Cell(60, 10, 'Product Name', 1);
$pdf->Cell(30, 10, 'Quantity', 1);
$pdf->Cell(40, 10, 'Unit Price (₹)', 1);
$pdf->Cell(40, 10, 'Total (₹)', 1);
$pdf->Ln();

$total_amount = 0;

// Fetch cart items
foreach ($_SESSION["cart_item"] as $item) {
    $item_price = $item["quantity"] * $item["price"];
    $total_amount += $item_price;

    $pdf->Cell(60, 10, $item["name"], 1);
    $pdf->Cell(30, 10, $item["quantity"], 1);
    $pdf->Cell(40, 10, number_format($item["price"], 2), 1);
    $pdf->Cell(40, 10, number_format($item_price, 2), 1);
    $pdf->Ln();
}

// Total Amount
$pdf->Cell(90, 10, 'Total Amount', 1);
$pdf->Cell(40, 10, '', 1);
$pdf->Cell(40, 10, '₹' . number_format($total_amount, 2), 1);
$pdf->Ln(20);

// Output PDF
$pdf->Output('D', 'Invoice.pdf');
exit();
?>
