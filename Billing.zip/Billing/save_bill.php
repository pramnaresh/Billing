<?php
include 'db_connect.php'; 

// Insert into bills table first
$bill_no = isset($_POST["bill_no"]) ? $_POST["bill_no"] : "";
$totalAmount = isset($_POST["totalAmount"]) ? $_POST["totalAmount"] : 0;
$customer_name = isset($_POST["customer_name"]) ? $_POST["customer_name"] : "";

$bill_no = uniqid(); // Generates a unique bill number
$billNo = $_POST['bill_no']; // Ensure this is coming from the form
$totalAmount = $_POST['totalAmount']; // Assuming totalAmount is in the form

$insertBillQuery = "INSERT INTO bills (bill_no, total_amount) VALUES ('$billNo', '$totalAmount')";
mysqli_query($conn, $insertBillQuery);

// Now insert into customers table
$customerName = $_POST['customer_name'];
$phoneNo = $_POST['phone_no'];

$insertCustomerQuery = "INSERT INTO customers (bill_no, customer_name, phone_no) VALUES ('$billNo', '$customerName', '$phoneNo')";
mysqli_query($conn, $insertCustomerQuery);
