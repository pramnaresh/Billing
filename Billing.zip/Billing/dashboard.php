<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
<!-- In your header.php file -->
<head>
    <link rel="stylesheet" href="css/styles.css">
</head>

<main class="dashboard-content">
    <!-- <h2>Welcome, <?= ($role === 'admin') ? "Admin $username" : "$username"; ?>!</h2> -->
    <!-- <p>Here's an overview of your billing performance.</p> -->
    <section class="cards">
                <div class="card">
                    <h1>Welcome To Billing Management System</h1>
                </div>
            </section>
    <!-- <section class="cards">
        <div class="card">
            <h3>50</h3>
            <p>Number of Sales</p>
        </div>
        <div class="card">
            <h3>$10,000</h3>
            <p>Sales Revenue</p>
        </div>
        <div class="card">
            <h3>$200</h3>
            <p>Average Price</p>
        </div>
    </section> -->
</main>

<?php include 'footer.php'; ?>
