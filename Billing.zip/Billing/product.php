<?php
include 'sidebar.php';
include 'header.php';
include 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Software</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <script src="script.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(214, 226, 169);
            color: #212529;
        }
        h1, h4 {
            text-align: center;
            margin-bottom: 10px;
        }
        .container {
            width: 1000px;
            height: 500px;
            margin: auto;
            padding: 20px;
            background: rgb(174, 223, 243);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .bg-section {
            background: rgb(177, 223, 164);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            max-height: 450px; 
            overflow-y: auto;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
        }
        .btn {
            width: 100%;
        }
        .scrollable-section {
            max-height: 450px; 
            overflow-y: auto;
        }
    </style>
</head>
<body>

<div class="container">
    <input type="hidden" id="totalAmountHidden" name="totalAmountHidden">

    <!-- <h3 class="text-center">Billing System</h3> -->

    <div class="row">
        <div class="col-md-12">
            <div class="bg-section">
                <h4>Products</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Price (₹)</th>
                            <!-- <th>Quantity</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $select_query = "SELECT * FROM products";
                        $result = mysqli_query($conn, $select_query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '
                                <tr style="background-color:rgb(249, 249, 249); border-bottom: 1px solid #ddd;">
                                    <td style="padding: 10px; text-align: center;">
                                        <img src="images/' . $row['image'] . '" width="50" height="50" alt="' . $row['name'] . '">
                                    </td>
                                    <td style="padding: 10px; font-weight: bold; color: #333;">' . $row['name'] . '</td>
                                    <td style="padding: 10px; color:rgb(70, 9, 237);">₹' . $row['price'] . '</td>
                                    
                                </tr>';
                            }
                        } else {
                            echo '<tr><td colspan="4" class="text-center" style="padding: 15px; font-weight: bold; color: red;">No products available</td></tr>';
                        }
                    ?>                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- <div class="row mt-3">
        <div class="col-md-6">
            <button class="btn btn-warning" onclick="calculateTotal()">Calculate Total</button>
        </div>
        <div class="col-md-6">
            <h4 id="totalAmount" class="text-end">Total: ₹0</h4>
        </div>
    </div> -->
</div>
</body>
</html>
<?php include 'footer.php'; ?>