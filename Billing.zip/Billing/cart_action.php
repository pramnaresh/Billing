<?php
session_start();
include 'db_connect.php';

if (isset($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add_multiple":
            if (isset($_POST["product_codes"])) {
                foreach ($_POST["product_codes"] as $id) {
                    if (isset($_POST["quantities"][$id])) {
                        $quantity = intval($_POST["quantities"][$id]);
                        $id = mysqli_real_escape_string($conn, $id);

                        // Fetch product details from the database
                        $result = $conn->query("SELECT * FROM products WHERE id = '$id'");
                        if ($product = $result->fetch_assoc()) {
                            $item = array(
                                "name" => $product["name"],
                                "price" => $product["price"],
                                "quantity" => $quantity,
                                "image" => $product["image"]
                            );

                            // Add item to the cart
                            $_SESSION["cart_item"][$id] = $item;
                        }
                    }
                }
            }
            header("Location: cart_view.php");
            exit();
            
            case "remove":
                if (!empty($_GET["id"])) {
                    $id = $_GET["id"];
                    
                    // Check if the item exists before removing it
                    if (isset($_SESSION["cart_item"][$id])) {
                        unset($_SESSION["cart_item"][$id]);
                    }
                }
                header("Location: cart_view.php");
                exit();                    

        case "empty":
            unset($_SESSION["cart_item"]);
            header("Location: cart_view.php");
            exit();
    }
}
?>
