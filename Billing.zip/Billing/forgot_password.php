<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "billingsystem";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    $query = "SELECT id FROM users WHERE email=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {

        $query = "SELECT id FROM admin WHERE email=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
    }

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(50));  
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour")); 

        $table = ($result->num_rows > 0) ? "users" : "admin";

        $query = "UPDATE $table SET reset_token=?, reset_token_expiry=? WHERE email=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $token, $expiry, $email);
        $stmt->execute();

        $reset_link = "http://localhost/reset_password.php?token=$token";

        echo "A reset link has been sent: <a href='$reset_link'>$reset_link</a>";
    } else {
        echo "Email not found!";
    }
}

$conn->close();
?>
