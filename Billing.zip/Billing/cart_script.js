let grandTotal = 0;

function addItem() {
    const itemName = document.getElementById('itemName').value;
    const quantity = parseInt(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);

    if (itemName && quantity > 0 && price >= 0) {
        const total = quantity * price;
        grandTotal += total;

        const tableBody = document.querySelector('#billingTable tbody');
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${itemName}</td>
            <td>${quantity}</td>
            <td>${price.toFixed(2)}</td>
            <td>${total.toFixed(2)}</td>
        `;
        tableBody.appendChild(row);

        document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);

        document.getElementById('itemName').value = '';
        document.getElementById('quantity').value = '';
        document.getElementById('price').value = '';
    }
}

async function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.text('Billing Management System', 10, 10);

    let y = 20;
    doc.text('Item Name    Quantity    Price    Total', 10, y);

    const rows = document.querySelectorAll('#billingTable tbody tr');
    rows.forEach(row => {
        y += 10;
        const cols = row.querySelectorAll('td');
        const rowData = Array.from(cols).map(col => col.textContent).join('    ');
        doc.text(rowData, 10, y);
    });

    y += 10;
    const grandTotal = document.getElementById('grandTotal').textContent;
    doc.text(`Grand Total: ${grandTotal}`, 10, y);

    doc.save('Billing_Invoice.pdf');
}
